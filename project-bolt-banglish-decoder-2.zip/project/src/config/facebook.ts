import { FacebookConfig } from '../services/facebook/types';

export const facebookConfig: FacebookConfig = {
  pageId: '100050562337903',
  accessToken: 'EAANFfGZBQLxIBOyW80lKTeZCkTM4ZB7ZBK2tyZC8q5ccveFfA4oqEEM1gZAew2pYf2E1Y9LjQeyhcL1XZBL2fNY5ZBLERuE31D6fvFStrNXJy3k9U76It8lkNQgeXhDr3Mulh9o57lTT5Ea8ltHXQFxCBdcmghGKXrWnaKElXa17z069ZBZAJYN6pSGQMZBSUlYNJdktnsQpfMyLNvNmws8ZBwZDZD',
  scrapeInterval: 60 // Scrape every hour
};